## ©RTX GAMING @2023
All rights reserved.

The code, and content of this application are protected by international copyright laws. Unauthorized reproduction or distribution of this application or any portion of it may result in severe civil and criminal penalties and will be prosecuted to the maximum extent possible under the law.

RTX GAMING retains all rights, including but not limited to the right to use, copy, distribute, and make derivative works of this application.

For inquiries about licensing, please contact [RTX#2419].

/**
 ██████╗░████████╗██╗░░██╗           
 ██╔══██╗╚══██╔══╝╚██╗██╔╝          
 ██████╔╝░░░██║░░░░╚███╔╝░          
 ██╔══██╗░░░██║░░░░██╔██╗░          
 ██║░░██║░░░██║░░░██╔╝╚██╗          
 ╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝          

  DISCORD SERVER : https://discord.gg/FUEHs7RCqz
  YOUTUBE : https://www.youtube.com/channel/UCPbAvYWBgnYhliJa1BIrv0A
 * **********************************************
 *   Code by RTX GAMING
 * **********************************************
 */
